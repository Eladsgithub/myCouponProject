package com.example.Facades;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.DBDAO.CompanyDBDAO;
import com.example.DBDAO.CouponDBDAO;
import com.example.DBDAO.CustomerDBDAO;
import com.example.Entity.Company;
import com.example.Entity.Customer;
import com.example.common.ClientType;



@Component
public class AdminFacade implements CouponClientFacade{
    @Autowired
    CompanyDBDAO companyDBDAO;
    @Autowired
    CustomerDBDAO customerDBDAO;
    @Autowired
    CouponDBDAO couponDBDAO;
    
	@Override
	public CouponClientFacade login(String name, String pwd, ClientType clinetType){
		
		if (name.equals("admin") && pwd.equals("1234"))
				return this;
		return null;
//		else throw new loginFailedException("login failed!");
			 
		}
	public void createCompany(Company c){
		companyDBDAO.createCompany(c);

	}
	public void removeCompany(Company c){
		companyDBDAO.removeCompany(c);
	}
	public void updateCompany(Company c){
		companyDBDAO.updateCompany(c);
	}
	public void getCompany(int id){
		companyDBDAO.getCompany(id);
	}
	public Collection<Company> getAllCompanies(){
		return companyDBDAO.getAllCompanies();
	} 
	public void createCustomer(Customer c){
		customerDBDAO.createCustomer(c);
	}
	public void removeCustomer(Customer c){
		customerDBDAO.removeCustomer(c);
	}
	public void updateCustomer(Customer c){
		customerDBDAO.updateCustomer(c);
	}
	public Collection<Customer> getAllCustomers(){
		return customerDBDAO.getAllCustomers();
	}

	public Customer getCustomer(int id){
		return customerDBDAO.getCustomer(id);
	}
}

