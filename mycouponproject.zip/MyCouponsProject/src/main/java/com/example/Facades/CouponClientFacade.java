package com.example.Facades;

import com.example.common.ClientType;
import com.example.common.CouponType;

public interface CouponClientFacade {

	

	CouponClientFacade login(String name, String pwd, ClientType clinetType);
}
