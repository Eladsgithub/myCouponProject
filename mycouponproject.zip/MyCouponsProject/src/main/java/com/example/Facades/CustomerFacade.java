package com.example.Facades;

import com.example.DBDAO.CustomerDBDAO;
import com.example.common.ClientType;

public class CustomerFacade implements CouponClientFacade{

	@Override
	public CouponClientFacade login(String name, String pwd, ClientType clinetType) {
		CustomerDBDAO customerDBDAO = new CustomerDBDAO();
		return null;
		
	
		
	}

}
