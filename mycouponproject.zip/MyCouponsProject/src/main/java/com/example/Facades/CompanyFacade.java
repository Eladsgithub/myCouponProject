package com.example.Facades;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.DBDAO.CompanyDBDAO;
import com.example.DBDAO.CouponDBDAO;
import com.example.Entity.Coupon;
import com.example.common.ClientType;
@Component
public class CompanyFacade implements CouponClientFacade{

	@Autowired
	CouponDBDAO couponDBDAO;
	@Autowired
	CompanyDBDAO companyDBDAO;
	
	@Override
	public CouponClientFacade login(String Comp_Name, String password, ClientType clinetType) {
		companyDBDAO.login(Comp_Name, password);
			
	return this;
	}
	
		public void createCoupon(Coupon c) {
			couponDBDAO.createCoupon(c);
				
			
		}
		
		public void removeCoupon(Coupon c) {
			couponDBDAO.removeCoupon(c);
	}
		public void updateCoupon(Coupon c) {
			couponDBDAO.updateCoupon(c);
		}
}


