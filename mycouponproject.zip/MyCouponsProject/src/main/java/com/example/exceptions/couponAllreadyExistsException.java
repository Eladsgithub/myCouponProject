package com.example.exceptions;

public class couponAllreadyExistsException extends RuntimeException  {
		public couponAllreadyExistsException (String message) {
			super(message);
			}
		
}
