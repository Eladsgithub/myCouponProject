package com.example.exceptions;

public class customerAllreadyExistsException extends RuntimeException {
	public customerAllreadyExistsException (String message){
		  super(message);
		}
}
