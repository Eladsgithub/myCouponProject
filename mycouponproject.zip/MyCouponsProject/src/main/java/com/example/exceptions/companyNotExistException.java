package com.example.exceptions;

public class companyNotExistException extends RuntimeException {
	public companyNotExistException (String message){
  super(message);
}
}