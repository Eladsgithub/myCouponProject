package com.example.exceptions;

public class couponDoesNotExistsException extends RuntimeException {
	public couponDoesNotExistsException(String message) {
	super(message);
}
}
