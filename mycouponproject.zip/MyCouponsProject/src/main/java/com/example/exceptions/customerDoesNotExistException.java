package com.example.exceptions;

public class customerDoesNotExistException extends RuntimeException {
	public customerDoesNotExistException  (String message){
		  super(message);
		}
}
