package com.example.exceptions;

public class companyAllreadyExistsException extends RuntimeException {

	public companyAllreadyExistsException (String message) {
		super(message);
	}
}
