package com.example.DAO;

import java.util.Collection;

import com.example.Entity.Company;
import com.example.Entity.Coupon;
import com.example.Entity.Customer;
import com.example.exceptions.customerAllreadyExistsException;
import com.example.exceptions.customerDoesNotExistException;

public interface CustomerDAO {
	
	
		 void createCustomer(Customer c) throws customerAllreadyExistsException;
		 void removeCustomer(Customer c) throws customerDoesNotExistException;
		 void updateCustomer(Customer c);
		 Customer getCustomer(int id);
		 Collection<Customer> getAllCustomers();
		 Collection<Coupon> getCoupons();
		boolean login(String customer_Name, String password);
		 
		  
		
		 
		
		
		
}
