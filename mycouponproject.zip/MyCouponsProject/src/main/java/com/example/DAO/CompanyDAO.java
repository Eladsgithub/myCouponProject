package com.example.DAO;



import java.util.Collection;

import com.example.Entity.Company;
import com.example.Entity.Coupon;
import com.example.exceptions.companyAllreadyExistsException;

public interface CompanyDAO {

		void createCompany(Company c) throws companyAllreadyExistsException;
		void removeCompany(Company c);
		void updateCompany(Company c);
		Company getCompany(int id);
		Collection<Company> getAllCompanies();
		Collection<Coupon> getCoupons();
		boolean login(String Comp_Name, String password);
		
		
}
