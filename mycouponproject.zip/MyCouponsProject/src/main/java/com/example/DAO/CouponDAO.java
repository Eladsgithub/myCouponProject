package com.example.DAO;

import java.util.Collection;

import com.example.Entity.Coupon;
import com.example.common.CouponType;
import com.example.exceptions.couponDoesNotExistsException;

public interface CouponDAO {
		
	
	void createCoupon(Coupon c);
	void removeCoupon(Coupon c) throws couponDoesNotExistsException;
	void updateCoupon(Coupon c);
	Coupon getCoupon(int id);
	Collection<Coupon> getAllCoupon();
	Collection<CouponType> getCouponByType(CouponType couponType);
	
	
}
