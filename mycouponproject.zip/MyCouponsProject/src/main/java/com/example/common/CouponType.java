package com.example.common;

public enum CouponType {
FOOD,
ELECTRICAPPLIANCE,
LEISURE,
VACATION	
}
