package com.example.common;

public enum ClientType {
ADMIN,
COMPNAY,
CUSTOMER
}
