package com.example.Entity.entry;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.example.Entity.Customer;
import com.example.Facades.AdminFacade;
import com.example.Facades.CompanyFacade;
import com.example.Facades.CouponClientFacade;
import com.example.Facades.CustomerFacade;
import com.example.common.ClientType;


@Component
@Scope("singleton")
public class CouponSystem {
	
	@Autowired
	AdminFacade adminFacade;
	
	
	
   public CouponClientFacade login(String name ,String pwd, ClientType clienttype){
	   switch (clienttype) {
	case ADMIN:
		 AdminFacade adminFacade = new AdminFacade();
		 AdminFacade result  = (AdminFacade) adminFacade.login(name, pwd, clienttype);
		 return result;
	case COMPNAY:
			CompanyFacade companyFacade = new CompanyFacade();
			CompanyFacade result1 = (CompanyFacade) companyFacade.login(name, pwd, clienttype);
			return result1;
	case CUSTOMER:
			CustomerFacade customerFacade = new CustomerFacade();
			CustomerFacade result2 = (CustomerFacade) customerFacade.login(name, pwd, clienttype);
			return result2;
	
	}
	return null;
	   
   }
	  
}
 