package com.example.Entity;

import java.util.Collection;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

import com.example.common.CouponType;
@Entity(name="COUPON")
public class Coupon {

	@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	@Column(name="PRICE")
	private double price;
	
	@Column(name="IMAGE")
	private String image;
	
	@Column(name="TITLE")
	private String title;
	
	@Column(name="START DATE")
	private Date start_Date;
	
	@Column(name="END DATE")
	private Date end_Date;
	
	@Column(name="AMOUNT")
	private Integer amount;
	
	@Column(name="TYPE")
	private CouponType type;
	
	@Column(name="MESSAGE")
	private String message;
	
	@ManyToMany(fetch = FetchType.EAGER, cascade = {CascadeType.DETACH , CascadeType.MERGE, CascadeType.REFRESH})
	@JoinTable(name = "customer_coupon",
	joinColumns = @JoinColumn(name = "coupon_id"),
	inverseJoinColumns = @JoinColumn(name = "customer_id"))
private Collection<Customer> customers;
	
	public Coupon(long id, String title, Date start_Date, Date end_Date, Integer amount, CouponType type, String message,
			double price, String image) {
		super();
//		this.id = id;
		this.title = title;
		this.start_Date = start_Date;
		this.end_Date = end_Date;
		this.amount = amount;
		this.type = type;
		this.message = message;
		this.price = price;
		this.image = image;
	}
	@Override
	public String toString() {
		return "Coupon [id=" + id + ", price=" + price + ", image=" + image + ", customers=" + customers.size() + ", title="
				+ title + ", start_Date=" + start_Date + ", end_Date=" + end_Date + ", amount=" + amount + ", type="
				+ type + ", message=" + message + "]";
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public Date getStart_Date() {
		return start_Date;
	}
	public void setStart_Date(Date start_Date) {
		this.start_Date = start_Date;
	}
	public Date getEnd_Date() {
		return end_Date;
	}
	public void setEnd_Date(Date end_Date) {
		this.end_Date = end_Date;
	}
	public Integer getAmount() {
		return amount;
	}
	public void setAmount(Integer amount) {
		this.amount = amount;
	}
	public CouponType getType() {
		return type;
	}
	public void setType(CouponType type) {
		this.type = type;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	
	public Coupon(long id, String title) {
		super();
		this.id = id;
		this.title = title;
	}
	public Coupon() {
		super();
	}

	
}
