package com.example.Entity;

import javax.persistence.Id;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CouponsProject2Application {

	public static void main(String[] args) {
		SpringApplication.run(CouponsProject2Application.class, args);
		
	}
	 
}
