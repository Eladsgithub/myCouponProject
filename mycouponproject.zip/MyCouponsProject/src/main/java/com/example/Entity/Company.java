package com.example.Entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
@Entity(name="COMPANY")
public class Company {

		
	@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
	private long Id;
	
	@Column(name="COMP_NAME")
	private String Comp_Name;
	
	@Column(name="PASSWORD")
	private String password;
	
	@Column(name="EMAIL")
	private String Email;
	
		
	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name="Company_id") 
	private List<Coupon> coupons;
	
	public List<Coupon> getCoupons() {
		return coupons;
	}
	public void setCoupons(List<Coupon> coupons) {
		this.coupons = coupons;
	}
	@Override
	public String toString() {
		return "Company [Id=" + Id + ", Comp_Name=" + Comp_Name + ", password=" + password + ", Email=" + Email + "]";
	}
	public Company(long id, String comp_Name, String password, String email) {
		super();
		Id = id;
		Comp_Name = comp_Name;
		this.password = password;
		Email = email;
	}
	
	public Company() {
	
	}
	public long getId() {
		return Id;
	}
	public void setId(long id) {
		Id = id;
	}
	public String getComp_Name() {
		return Comp_Name;
	}
	public void setComp_Name(String comp_Name) {
		Comp_Name = comp_Name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}

}
