package com.example.DBDAO;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.example.Entity.Coupon;
import com.example.Entity.Customer;

public interface CustomerRepo extends CrudRepository<Customer, Integer>{

	boolean findCustomerByCustomer_NameAndPassword(String customer_Name, String password);

	boolean existsByComp_Name(String customer_Name);

	boolean existsByCustomer_Name(String customer_Name);

	boolean existsByCustomer_name(String customer_Name);
}
