package com.example.DBDAO;

import org.springframework.data.repository.CrudRepository;

import com.example.Entity.Company;


public interface CompanyRepo extends CrudRepository<Company, Integer>{

	boolean existsByComp_NameAndPassword(String comp_Name, String password);

	boolean existsById(long id);

	boolean existsByComp_Name(String comp_Name);

}
