package com.example.DBDAO;

import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.DAO.CompanyDAO;
import com.example.Entity.Company;
import com.example.Entity.Coupon;
import com.example.exceptions.companyAllreadyExistsException;
import com.example.exceptions.companyNotExistException;


@Component
public class CompanyDBDAO implements CompanyDAO{

	@Autowired
	CompanyRepo companyRepo;
	@Autowired
	CouponRepo couponRepo;
			
	 
	
	@Override
	public void createCompany(Company c) throws companyAllreadyExistsException
	{
	if (companyRepo.existsByComp_Name(c.getComp_Name())) throw new 
		companyAllreadyExistsException("Company Name Allready Exists");
	else companyRepo.save(c);
		 
	}

	@Override
	public void removeCompany(Company c) throws companyNotExistException {
		if (companyRepo.existsByComp_Name(c.getComp_Name()))
			companyRepo.delete(c);
		else throw new companyNotExistException("Company does not exist");
		
	}
	
//    removed the setcompanyName is it legal  - ctor not affected  
	@Override
	public void updateCompany(Company c) throws companyNotExistException{
		if (companyRepo.existsByComp_Name(c.getComp_Name())){
		c.setEmail(c.getEmail());
		c.setPassword(c.getPassword());
		companyRepo.save(c);}
	    else  {
	    	throw new companyNotExistException("Company does not exist");
	    }
	    }

	@Override
	public Company getCompany(int id) {
	Company c = companyRepo.findOne(id);
	return c;
	}
	@Override
	public Collection<Company> getAllCompanies() {
		List<Company> listOfAllCompanies = (List<Company>) companyRepo.findAll();
		return listOfAllCompanies;
	}
	
//
//	@Override
//	public Collection<Coupon> getCouponsByCouponType() {
//		List<Coupon> listOfAllCoupons = (List<Coupon>) couponRepo.findAll();
//		return listOfAllCoupons;
//		@Override
//		
//	public Collection<Coupon> getCoupons() {
//			List<Coupon> listOfAllCoupons = (List<Coupon>) couponRepo.findAll();
//			return listOfAllCoupons;
//			@Override
//			
//	public Collection<Coupon> getCoupons() {
//				List<Coupon> listOfAllCoupons = (List<Coupon>) couponRepo.findAll();
//				return listOfAllCoupons;
//	
//		
//	}

	@Override
	public boolean login(String Comp_Name, String password) {
		if (companyRepo.existsByComp_NameAndPassword(Comp_Name, password))
				{System.out.println("login succesful , welcome");}
		return true;
		
		}

	@Override
	public Collection<Coupon> getCoupons() {
		// TODO Auto-generated method stub
		return null;
	}
			}

	
	


