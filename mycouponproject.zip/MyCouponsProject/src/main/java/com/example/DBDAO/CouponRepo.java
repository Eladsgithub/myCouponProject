package com.example.DBDAO;

import org.springframework.data.repository.CrudRepository;

import com.example.Entity.Coupon;

public interface CouponRepo extends CrudRepository<Coupon, Integer>{

	boolean existsByTitle(String title);

	boolean existsById(long id);

}
