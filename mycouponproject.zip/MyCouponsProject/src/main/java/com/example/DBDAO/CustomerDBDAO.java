package com.example.DBDAO;

import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.DAO.CustomerDAO;
import com.example.Entity.Coupon;
import com.example.Entity.Customer;
import com.example.exceptions.companyAllreadyExistsException;
import com.example.exceptions.customerAllreadyExistsException;
import com.example.exceptions.customerDoesNotExistException;

@Component
public class CustomerDBDAO implements CustomerDAO{

	@Autowired
	CustomerRepo customerRepo;
	 
	@Override
	public boolean login(String Customer_Name, String password) {
		if(customerRepo.findCustomerByCustomer_NameAndPassword(Customer_Name, password)){	
 			System.out.println("login succesful , welcome");	 }
	
		return false;
		
	}
	
	@Override
	public void createCustomer(Customer c) throws customerAllreadyExistsException {
		if (customerRepo.existsByComp_Name(c.getCustomer_Name())) throw new 
		customerAllreadyExistsException("Customer Allready Exists");
	else customerRepo.save(c);
		
	}

	@Override
	public void removeCustomer(Customer c) throws customerDoesNotExistException  {
		if (customerRepo.existsByCustomer_Name(c.getCustomer_Name())) 
			customerRepo.delete(c);
	else throw new 
	customerDoesNotExistException("Customer does not Exist");
		
	}

	@Override
	public void updateCustomer(Customer c) {
		if (customerRepo.existsByCustomer_name(c.getCustomer_Name())){
		c.setPassword(c.getPassword());
			customerRepo.save(c);}
			else {
				throw new customerDoesNotExistException("Customer does not Exist");
			}		
		}
	@Override
	public Customer getCustomer(int id) {
		Customer c = customerRepo.findOne(id);
		return c;
		
	}

	@Override
	public Collection<Customer> getAllCustomers() {
		List<Customer> listOfAllCustomers = (List<Customer>) customerRepo.findAll();
		return listOfAllCustomers;	
	}

	@Override
	public Coupon getCoupons() {
		return null;
		
		
	}




