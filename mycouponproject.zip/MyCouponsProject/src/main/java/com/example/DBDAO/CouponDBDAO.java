package com.example.DBDAO;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.DAO.CouponDAO;
import com.example.Entity.Coupon;
import com.example.common.CouponType;
import com.example.exceptions.CouponAllreadyExistsException;
import com.example.exceptions.couponAllreadyExistsException;
import com.example.exceptions.couponDoesNotExistsException;
@Component
public class CouponDBDAO implements CouponDAO{

	@Autowired
	CouponRepo couponRepo;
	
	@Override
	public void createCoupon(Coupon c) throws couponAllreadyExistsException{
		if(couponRepo.existsByTitle(c.getTitle())) throw new 
		couponAllreadyExistsException("Coupon allready exists");
		
		else {
			couponRepo.save(c);
			}
		}

	@Override
	public void removeCoupon(Coupon c) throws couponDoesNotExistsException {
		if (couponRepo.existsByTitle(c.getTitle()))
		couponRepo.delete(c);
		else {throw new couponDoesNotExistsException("coupon does not exist");
		}
		}
	

	@Override
	public void updateCoupon(Coupon c) {
//		(companyRepo.existsById(c.getId()))	
//		companyRepo.save(c);
		couponRepo.save(c);
		
	}

	@Override
	public Coupon getCoupon(int id) {
		 Coupon c= couponRepo.findOne(id);
		 return c;
		
		
	}

	@Override
	public Collection<Coupon> getAllCoupon() {
		Collection<Coupon> listOfAllCoupons = (Collection<Coupon>) couponRepo.findAll()
		return listOfAllCoupons ;
		
		
	}

	@Override
	public Collection<CouponType> getCouponByType(CouponType couponType) {
		return couponType;
	
		
	}

	


}
